import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class OneThread extends Thread
{
    private static String jdbcUrl;
    private static String userName;
    private static String passwd;

    private static String sql = "select count(*) from pg_class;";
    private static int queryPerThread = 1;
    private static boolean enableAutoCommit;
    private static String beforeSql = null;
    private int flag;

    public OneThread(String jdbcUrl, String userName, String passwd, String sql,
                     int queryPerThread, boolean enableAutoCommit, String beforeSql, int flag)
    {
        OneThread.jdbcUrl = jdbcUrl;
        OneThread.userName = userName;
        OneThread.passwd = passwd;
        OneThread.sql = sql;
        OneThread.queryPerThread = queryPerThread;
        this.enableAutoCommit = enableAutoCommit;
        this.beforeSql = beforeSql;
        this.flag = flag;
    }

    public void run()
    {
        if (OneThread.jdbcUrl.equals(""))
        {
            for (int i = 0; i < OneThread.queryPerThread; ++i)
            {
                System.out.print(this.flag);
            }
        }
        else
        {
            this.runOneThread();
        }
    }

    public void runOneThread()
    {
        try
        {
            Class.forName("org.postgresql.Driver");
            Connection conn = DriverManager.getConnection(OneThread.jdbcUrl, OneThread.userName, OneThread.passwd);
//            Connection conn = DriverManager.getConnection("jdbc:postgresql://59.202.45.91:3432/kxzz?" +
//                            "user=huixin&password=Hxkj1234&gp_session_role=utility");

            conn.setAutoCommit(enableAutoCommit);
            Statement stmt = conn.createStatement();

            if (beforeSql != null) {
                stmt.execute(beforeSql);
            }

            for (int i = 0; i < OneThread.queryPerThread; ++i)
            {
                // no print results
                stmt.executeQuery(OneThread.sql);
                stmt.getResultSet();
            }

            stmt.close();
            conn.close();
        }
        catch (ClassNotFoundException | SQLException e)
        {
            e.printStackTrace();
        }
    }
}