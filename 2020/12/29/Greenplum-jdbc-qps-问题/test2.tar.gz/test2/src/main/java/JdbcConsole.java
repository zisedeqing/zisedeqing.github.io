import java.sql.*;
import java.util.Scanner;

public class JdbcConsole {
    static Connection conn = null;
    static Statement stmt = null;
    static String url = "jdbc:postgresql://localhost:15432/postgres";
    static String dbname = "postgres";
    static String dbuser = "postgres";

    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.print("input sql:");
            System.out.flush();

            String nextline = sc.nextLine();
            System.out.println("read: " + nextline);

            nextline = nextline.trim();
            if (nextline.length() == 0) {
                continue;
            }

            if (nextline.equalsIgnoreCase("q") ||
                nextline.equalsIgnoreCase("quit") ||
                nextline.equalsIgnoreCase("exit")) {
                break;
            }

            try {
                execSql(nextline);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (conn != null) {
            conn.close();
        }
    }

    public static void execSql(String sql) throws ClassNotFoundException, SQLException {

        if (conn == null) {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(url, dbuser, "");
            conn.setAutoCommit(true);
            stmt = conn.createStatement();
        }

        if (stmt.execute(sql)) {
            ResultSet rs = stmt.getResultSet();

            if (rs != null) {
                ResultSetMetaData rsm = rs.getMetaData();
                while (rs.next()) {
//                System.out.println("-----row--------");
                    for (int i = 1; i <= rsm.getColumnCount(); i++) {
                        System.out.println(rsm.getColumnName(i) + ":" + rs.getString(i));
                    }
                }
                rs.close();
            }
        }
    }
}
