public class MainEntry
{
    private static String jdbcUrl = "";
    private static String userName = "";
    private static String passwd = "";

    private static String sql = "select count(*) from pg_class;";
    private static int queryPerThread = 10;
    private static int numThread = 10;
    private static boolean enableAutoCommit = false;
    private static String beforeSql = null;

    public static void main(String[] args)
    {
        // Parameters
        if (args.length >= 7)
        {
            MainEntry.jdbcUrl = args[0];
            MainEntry.userName = args[1];
            MainEntry.passwd = args[2];
            System.out.println(jdbcUrl);

            MainEntry.sql = args[3];
            MainEntry.queryPerThread = Integer.parseInt(args[4]);
            MainEntry.numThread = Integer.parseInt(args[5]);
            MainEntry.enableAutoCommit = Boolean.valueOf(args[6]);

            if (args.length == 8) {
                MainEntry.beforeSql = args[7];
            }
        }

        // Start
        System.out.println("QPS Tester: start");
        long startTime = System.currentTimeMillis();
        try
        {
            OneThread [] threads = new OneThread[MainEntry.numThread];
            for (int i = 0; i < MainEntry.numThread; ++i)
            {
                threads[i] = new OneThread(MainEntry.jdbcUrl, MainEntry.userName, MainEntry.passwd,
                        MainEntry.sql, MainEntry.queryPerThread, MainEntry.enableAutoCommit, MainEntry.beforeSql, i);
                threads[i].start();
            }
            for (int i = 0; i < MainEntry.numThread; ++i)
            {
                threads[i].join();
            }
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        long endTime = System.currentTimeMillis();
        System.out.println("");
        System.out.println("QPS Tester: end");

        // results
        long diff = endTime - startTime;
        System.out.println("Total run time: " + diff + " ms");
        System.out.println("QPS Tester: QPS = [" + (MainEntry.queryPerThread * MainEntry.numThread / (diff / 1000.0)) + "] querys/s");
    }
}
